module.exports = {
    set: (req, data) => {},
    get: (req) => { return undefined; }
};