export default {
    NAV_ACTIVATE: 'NAV_ACTIVATE'
};