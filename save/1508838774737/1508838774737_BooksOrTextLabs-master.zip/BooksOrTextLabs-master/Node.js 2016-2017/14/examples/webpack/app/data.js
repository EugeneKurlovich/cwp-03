export default {
    comments: [
        { id: 1, author: 'The Ancient One', text: 'Have you seen that at a gift shop?' },
        { id: 2, author: 'Dr. Strange', text: 'Teach me.' },
        { id: 3, author: 'The Ancient One', text: 'No.' },
    ]
}